package stage;

import java.awt.Color;
import java.util.*;
import arkanoid_object.*;

public class stage3 {
	private ArrayList<brick> bricks;
	private ArrayList<Thread> bricks_th;
	private int stage_num;

	public stage3(character ch,ball b) {
		stage_num = 3;
		bricks = new ArrayList<brick>();
		bricks_th = new ArrayList<Thread>();
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 2; j++) {
				bricks.add(2 * i + j, new brick());
				bricks.get(2 * i + j).setX(100 + 400 * j);
				bricks.get(2 * i + j).setY(20 * i + 300);
				bricks.get(2 * i + j).setCollision(b);
				bricks_th.add(2 * i + j, new Thread(bricks.get(2 * i + j).th));
				bricks.get(2 * i + j).getPan().setSize(bricks.get(2 * i + j).getSize_x(),
						bricks.get(2 * i + j).getSize_y());
				bricks.get(2 * i + j).getPan().setLocation(bricks.get(2 * i + j).getX(), bricks.get(2 * i + j).getY());
				if ((2 * i + j) % 4 %3== 0)
					bricks.get(2 * i + j).getPan().setBackground(Color.orange);
				else
					bricks.get(2 * i + j).getPan().setBackground(Color.YELLOW);
			}
		}
	}

	public HashMap<Integer, ArrayList<Thread>> returnbricks() {
		HashMap<Integer, ArrayList<Thread>> map = new HashMap<Integer, ArrayList<Thread>>();
		map.put(stage_num, bricks_th);
		return map;
	}

	public ArrayList<brick> getBricks() {
		return bricks;
	}

	public ArrayList<Thread> getBricks_th() {
		return bricks_th;
	}

	public int getStage_num() {
		return stage_num;
	}

}
