package stage;

import java.awt.Color;
import java.io.IOException;
import java.util.*;
import arkanoid_object.*;

public class stage2 {
	private ArrayList<brick> bricks;
	private ArrayList<Thread> bricks_th;
	private int stage_num;

	public stage2(character ch,ball b) throws IOException {
		stage_num = 2;
		bricks = new ArrayList<brick>();
		bricks_th = new ArrayList<Thread>();
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				bricks.add(7 * i + j, new brick());
				bricks.get(7 * i + j).setX(150 + 50 * j);
				bricks.get(7 * i + j).setY(20 * i + 80);
				bricks.get(7 * i + j).setCollision(b);
				bricks_th.add(7 * i + j, new Thread(bricks.get(7 * i + j).th));
				bricks.get(7 * i + j).getPan().setSize(bricks.get(7 * i + j).getSize_x(),
						bricks.get(7 * i + j).getSize_y());
				bricks.get(7 * i + j).getPan().setLocation(bricks.get(7 * i + j).getX(), bricks.get(7 * i + j).getY());
				bricks.get(7 * i + j).setBrick_image("images\\Block\\Block_yellow.png");
			}
		}
	}

	public HashMap<Integer, ArrayList<Thread>> returnbricks() {
		HashMap<Integer, ArrayList<Thread>> map = new HashMap<Integer, ArrayList<Thread>>();
		map.put(stage_num, bricks_th);
		return map;
	}

	public ArrayList<brick> getBricks() {
		return bricks;
	}

	public ArrayList<Thread> getBricks_th() {
		return bricks_th;
	}

	public int getStage_num() {
		return stage_num;
	}
	
	public String getH_wall(){
		return "images\\desert\\desert_pillar_cols.png";
	}
	public String getW_wall(){
		return "images\\desert\\desert_pillar_rows.png";
	}
	public String getball_image() {
		return "images\\desert\\desert_ball.png";
	}
	public String getBackground_image() {
		return "images\\desert\\desert_back.png";
	}
}
