package arkanoid_object;

import javax.swing.JComponent;

public class character_status extends JComponent{

	
	//캐릭터의 hp
	private int hp;
	
	//캐릭터의 좌표
	private int x;
	private int y=850;
	
	//캐릭터의 x벡터값
	private int dx=0;
	
	//캐릭터의 크기
	private int size_x;
	private int size_y=20;
	
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public void Hpadd() {
		this.hp = ++hp;
	}
	public void Hpremove(int hp) {
		this.hp = --hp;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public int getSize_y() {
		return size_y;
	}
	public int getDx() {
		return dx;
	}
	public void setDx(int dx) {
		this.dx=dx;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	public int getSize_x() {
		return size_x;
	}
	public void setSize_x(int size_x) {
		this.size_x = size_x;	
	}
	
	

}
