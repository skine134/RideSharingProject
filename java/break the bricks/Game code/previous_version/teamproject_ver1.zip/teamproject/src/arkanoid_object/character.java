package arkanoid_object;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPanel;

import event.Item;

public class character extends character_status {

	// 충돌 처리를 위한 함수 람다식으로 구현
	private Collision ball_col = (JComponent e) -> {
		
		ball b=(ball)e;
		// 만약 캐릭터와 충돌 했을때 true 반환 충돌하지 않았다면 false 반환
		if ((b.getX() + b.getR()) >= this.getX() && 
			(b.getY() + b.getR()) >= this.getY()&& 
			(b.getX()) <= (this.getX() + this.getSize_x()) &&
			(b.getY()) <= (this.getY() + this.getSize_y())) {
			return true;
		} else
			return false;
	};
	
	// 아이템 충돌 처리를 위한 함수 람다식으로 구현
	private Collision items_col=(JComponent e) -> {
		
		Item i=(Item)e;
		// 만약 캐릭터와 충돌 했을때 true 반환 충돌하지 않았다면 false 반환
		if ((i.getX()+i.getSize_x()) >= this.getX() && 
			(i.getY()+i.getSize_y()) >= this.getY()&& 
			(i.getX()) <= (this.getX() + this.getSize_x()) &&
			(i.getY()) <= (this.getY() + this.getSize_y())) {
			return true;
		} else
			return false;
	};
	// character에대한 스레드 선언
	public Runnable ball_th;
	public Runnable items_th;
	// character을 담아낼 pan 선언
	private JPanel pan;

	public character() {

		// character의 x사이즈 설정(※y사이즈는 변동될 일이 없으므로 선언 전에 설정 됌)
		setSize_x(100);

		// character의 x좌표 선언(※y좌표는 변동될 일이 없으므로 선언 전에 설정 됌)
		setX(246);

		// character의 hp 구현(3칸)
		setHp(3);

		// character의 초기 x벡터선언(※y벡터는 변동될 일이 없으므로 구현되지 않음)
		setDx(0);

		// character을 담아낼 pan 객체 선언 및 이미지 지정
		pan = new JPanel() {
			@Override
			public void paintComponent(Graphics g){
				super.paintComponent(g);
				ImageIcon image=new ImageIcon("images\\character.png");
				g.drawImage(image.getImage(),0,0,getWidth(),getHeight(),null);
			}
		};

		// character을 담아낼 pan의 사이즈 지정
		pan.setSize(getSize_x(), getSize_y());
	}

	// character를 담은pan 반환
	public JPanel getPan() {
		return pan;
	}

	// 충돌 시 일어나는 이벤트 스레드구현
	public void setCollision(ball b) {

		ball_th = () -> {
			while (true) {

				// 만약 충돌이 일어났다면
				if (ball_col.collision(b)) {

					// 공의 y벡터는 반전 (다시 올라가도록)하고 공의 x벡터는 캐릭터가 움직이던 방향으로 설정
					b.setDy(-b.getDy());
					b.setDx(this.getDx());
					try {
						// 스레드가 연속해서 일어나는오류를 방지하기위해 충돌 후 0.5초간 상기된 이벤트 정지
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.getMessage();
					}
				}
				try {

					// 충돌에 대한 감시를 1초당60번 수행
					Thread.sleep(1000 / 60);
				} catch (InterruptedException e) {
					e.getMessage();
				}
			}
		};

	}

	//아이템 충돌 시 일어나는 이벤트 스레드구현
		public void setCollision(ArrayList<Item> items) {

			items_th = () -> {
				while (true) {
					//아이템을 갖고 있다면 하위의 명령어 실행
					if(items!=null)
					for(int i=0;i<items.size();i++) {
						
						//만약 충돌이 일어났다면
						if (items_col.collision(items.get(i))) {
							
							//아이템의 이벤트 실헹
							items.get(i).play_event(this);
							items.get(i).getPan().setVisible(false);
							items.remove(i);
							
						}
					}
					try {
						
						//충돌에 대한 감시를 1초당60번 수행
						Thread.sleep(1000 / 60);
					} catch (InterruptedException e) {
						e.getMessage();
					}
				}
			};

		}
}
