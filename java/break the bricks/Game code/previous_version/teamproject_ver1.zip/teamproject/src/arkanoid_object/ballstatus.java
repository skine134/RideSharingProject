package arkanoid_object;

import javax.swing.ImageIcon;
import javax.swing.JComponent;

public class ballstatus extends JComponent{
	
	//배속
	private double speed;
	
	//이전 x,y값
	private int pre_x;
	private int pre_y;
	
	//현제 x,y값
	private int x;
	private int y;
	
	//공의 투명성 여부
	private boolean ballclear;
	
	//공의 지름
	private int r;
	
	//각 축에대한 공의 변화량
	private int dx;
	private int dy;
	

	public double getSpeed() {
		return speed;
	}
	
	public int getDx() {
		return dx;
	}

	public void setDx(int dx) {
		this.dx = dx;
	}

	public int getDy() {
		return dy;
	}

	public void setDy(int dy) {
		this.dy = dy;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public int getPre_x() {
		return pre_x;
	}
	public void setPre_x(int pre_x) {
		this.pre_x = pre_x;
	}
	public int getPre_y() {
		return pre_y;
	}
	public void setPre_y(int pre_y) {
		this.pre_y = pre_y;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public boolean isBallclear() {
		return ballclear;
	}
	public void setBallclear(boolean ballclear) {
		this.ballclear = ballclear;
	}
	public int getR() {
		return r;
	}
	public void setR(int r) {
		this.r = r;
	}
	
	
	
}
